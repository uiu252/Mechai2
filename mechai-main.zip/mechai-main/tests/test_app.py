from pathlib import Path
import pytest
from streamlit.testing.v1 import AppTest

APP=Path(__file__).resolve().parents[1]/'app.py'

def button(at,label):
    return next(b for b in at.button if b.label==label)

def open_stage(at,stage):
    at.radio(key='stage').set_value(stage).run()
    assert not at.exception

def test_full_ui_human_disagreement_and_override():
    at=AppTest.from_file(str(APP),default_timeout=30).run()
    assert not at.exception
    assert at.metric[0].value=='16 / 16'
    assert len(at.session_state['products'])==26
    open_stage(at,'Specialist review')
    button(at,'Load demo perspectives').click().run()
    assert not at.exception
    assert len(at.session_state['analyses'])==3
    epoch=at.session_state['review_epoch']
    at.radio(key=f'decision_0_{epoch}').set_value('Disagree')
    at.text_area(key=f'comment_0_{epoch}').set_value('Retain the Reaper Inflatable: 4.8 stars from 75 reviews. Supplier demand is unproven.')
    next(b for b in at.button if b.label=='Save human review').click().run()
    assert not at.exception
    assert at.session_state['reviews']['Financial'].decision=='Disagree'
    [b for b in at.button if b.label=='Save human review'][1].click().run()
    [b for b in at.button if b.label=='Save human review'][2].click().run()
    assert len(at.session_state['reviews'])==3
    open_stage(at,'Executive synthesis')
    button(at,'Synthesize recommendation').click().run()
    assert not at.exception
    assert at.session_state['synthesis'].reviewer_responses[0].decision=='Disagree'
    open_stage(at,'Merchant decision')
    next(x for x in at.text_area if x.label=='Merchant rationale').set_value('Merchant accepts these placements but overrides the synthesis confidence: launch remains provisional.')
    button(at,'Override recommendation').click().run()
    assert not at.exception
    record=at.session_state['final_record']
    assert record['merchant_decision']['decision']=='Override'
    assert record['validation']['valid']
    assert len(record['products'])==26

def test_ui_validation_and_stale_review_reset():
    at=AppTest.from_file(str(APP),default_timeout=30).run()
    open_stage(at,'Specialist review')
    button(at,'Load demo perspectives').click().run()
    open_stage(at,'Assortment')
    version=at.session_state['editor_version']
    # Streamlit AppTest has no DataEditor element yet: supply the same edit delta emitted by the widget.
    at.session_state[f'workspace_{version}']={'edited_rows':{10:{'Placement':'Removed'}},'added_rows':[],'deleted_rows':[]}
    button(at,'Save placements & validate').click().run()
    assert not at.exception
    assert at.metric[0].value=='15 / 16'
    assert 'analyses' not in at.session_state
    open_stage(at,'Executive synthesis')
    assert button(at,'Synthesize recommendation').disabled

def test_ui_missing_reviewer_comment_blocks_save():
    at=AppTest.from_file(str(APP),default_timeout=30).run()
    open_stage(at,'Specialist review')
    button(at,'Load demo perspectives').click().run()
    epoch=at.session_state['review_epoch']
    at.radio(key=f'decision_0_{epoch}').set_value('Modify')
    next(b for b in at.button if b.label=='Save human review').click().run()
    assert not at.exception
    assert len(at.session_state['reviews'])==0
    assert any('explanation' in e.value for e in at.error)

def test_ui_api_failure_keeps_demo_usable(monkeypatch):
    monkeypatch.delenv('OPENAI_API_KEY',raising=False)
    at=AppTest.from_file(str(APP),default_timeout=30).run()
    at.radio(key='mode').set_value('Live AI').run()
    open_stage(at,'Specialist review')
    button(at,'Run three perspectives').click().run()
    assert not at.exception
    assert 'Analysis did not complete' in at.session_state['job_error']
    at.radio(key='mode').set_value('Demo Mode').run()
    button(at,'Load demo perspectives').click().run()
    assert len(at.session_state['analyses'])==3
    assert not at.session_state['busy']
