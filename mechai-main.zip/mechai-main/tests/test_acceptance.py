from io import BytesIO
import json
from types import SimpleNamespace
from unittest.mock import Mock
import pytest
from openpyxl import Workbook
from data_loader import load_products, fingerprint, source_warnings, WorkbookError
from rules import validate_assortment, apply_changes
from schemas import Product, ROLES, Review, Change, MerchantDecision, Perspective
from agents import (demo_analyses, offline_perspective, offline_synthesis, live_analyses,
    live_synthesis, validate_synthesis, validate_evidence, make_client)
from workflow import finalize, summary_markdown, placements_csv, record_json
from scenarios import load_scenario

@pytest.fixture
def products(): return load_products()

def placement(products, name, target):
    return [p.model_copy(update={'placement':target}) if p.item == name else p.model_copy() for p in products]

def reviews(decision='Agree', comment=''):
    return [Review(role=r,decision=decision if i==0 else 'Agree',comment=comment if i==0 else '') for i,r in enumerate(ROLES)]

def final_record(products, decision='Accept', rationale='', final_products=None):
    analyses, source, _ = demo_analyses(products)
    human = reviews()
    synthesis = offline_synthesis(products,analyses,human)
    final_products = final_products or apply_changes(products,synthesis.recommended_changes)
    return finalize(products, final_products, analyses,human,synthesis,
        MerchantDecision(decision=decision,rationale=rationale),fingerprint(products),source,'Rule-based demo synthesis')

def test_AC1_actual_workbook_both_sections(products):
    assert len(products) == 26
    assert sum(p.source_type=='current' for p in products) == 16
    assert sum(p.source_type=='new_candidate' for p in products) == 10
    dragon = next(p for p in products if 'Dragon' in p.item)
    assert dragon.mandatory_purchase_quantity == 45000
    assert dragon.gross_margin_dollars == 9405000
    assert dragon.source_row == 27
    assert dragon.star_rating is None and dragon.full_price_sell_through is None
    assert dragon.reviews is None
    fog = next(p for p in products if p.item == 'LED Fog Machine')
    assert fog.gross_margin_dollars == 48500 and fog.full_price_sell_through == .32

def test_AC2_15_facings_fail_and_block_synthesis(products):
    edited = placement(products,'LED Fog Machine','Removed')
    v = validate_assortment(edited)
    assert v.total_facings == 15 and not v.facings_valid
    with pytest.raises(ValueError,match='Fix assortment'): offline_synthesis(edited,demo_analyses(edited)[0],reviews())
    with pytest.raises(ValueError,match='Cannot finalize'): final_record(products,decision='Override',rationale='Test',final_products=edited)

def test_AC3_16_facings_pass(products):
    v = validate_assortment(products)
    assert v.valid and v.total_facings == 16 and v.online_count == 4

def test_AC4_five_online_fail(products):
    v = validate_assortment(placement(products,'14 ft Giant Animated Dragon','Online Only'))
    assert v.online_count == 5 and not v.online_valid

def test_AC5_missing_category_fails(products):
    edited = [p.model_copy(update={'placement':'Removed'}) if p.category=='Inflatables' else p for p in products]
    v = validate_assortment(edited)
    assert not v.categories_valid and v.missing_categories==['Inflatables']

def test_AC6_three_distinct_structured_perspectives(products):
    analyses, label, provenance = demo_analyses(products)
    assert label == 'Cached demo analysis'
    assert 'not prior live' in provenance
    assert set(analyses)==set(ROLES)
    assert len({a.model_dump_json() for a in analyses.values()})==3
    for a in analyses.values():
        assert 3<=len(a.findings)<=5
        validate_evidence(a,products)

def test_AC7_human_modify_changes_synthesis(products):
    analyses = demo_analyses(products)[0]
    all_agree = offline_synthesis(products,analyses,reviews())
    human = reviews('Modify','Keep the Reaper Inflatable; its rating is 4.8 from 75 reviews. Do not approve an unproven replacement.')
    changed = offline_synthesis(products,analyses,human)
    assert human[0].comment in '\n'.join(changed.conflicts)
    assert not any(c.product=='12 ft Reaper Inflatable' for c in changed.recommended_changes)
    assert len(changed.recommended_changes) < len(all_agree.recommended_changes)
    assert changed.reviewer_responses[0].comment == human[0].comment

def test_AC8_api_failure_does_not_break_demo(products,monkeypatch):
    monkeypatch.delenv('OPENAI_API_KEY',raising=False)
    with pytest.raises(ValueError,match='No API key'): make_client()
    bad = SimpleNamespace(responses=SimpleNamespace(parse=Mock(side_effect=TimeoutError('offline'))))
    with pytest.raises(TimeoutError): live_analyses(products,client=bad)
    assert len(demo_analyses(products)[0]) == 3

def test_AC9_override_rationale_and_revalidation(products):
    record = final_record(products,decision='Override',rationale='Retain historical assortment pending evidence for new candidates.',final_products=products)
    assert record['merchant_decision']['decision']=='Override'
    assert record['merchant_decision']['rationale']
    assert record['validation']['valid']
    with pytest.raises(ValueError): MerchantDecision(decision='Override',rationale='   ')

def test_AC10_export_every_item_exactly_once(products):
    record = final_record(products)
    assert len(record['products'])==26
    assert len({p['item'] for p in record['products']})==26
    assert record['validation']['total_facings']==16
    summary = summary_markdown(record)
    assert '16/16 facings' in summary and '4/4 online-only' in summary
    assert 'Supplier estimate' in summary and 'Historical actuals' in summary
    assert 'gross_margin_basis' in placements_csv(record)
    assert json.loads(record_json(record))['validation']['valid']

@pytest.mark.parametrize('scenario',['Dragon challenge','Bluetooth fog challenge'])
def test_required_demo_scenarios_valid(products,scenario):
    edited = load_scenario(products,scenario)
    assert validate_assortment(edited).valid
    analyses,label,_ = demo_analyses(edited)
    assert label=='Rule-based offline analysis'
    assert len(analyses)==3

def test_dragon_challenge_grounded(products):
    analyses = demo_analyses(load_scenario(products,'Dragon challenge'))[0]
    f = ' '.join(x.claim for x in analyses['Financial'].findings)
    o = ' '.join(x.claim for x in analyses['Operations and Channel'].findings)
    assert '$9,405,000' in f and '45,000' in f and 'not realized' in f
    assert '25%' in o

def test_fog_comparison_grounded(products):
    a = offline_perspective(products,'Financial')
    text = ' '.join(f.claim for f in a.findings)
    assert '$740,000' in text and '20,000' in text and '32.0%' in text and '$48,500' in text

def test_disagree_withholds_agent_changes(products):
    synthesis = offline_synthesis(products,demo_analyses(products)[0],reviews('Disagree','Reject replacement: supplier demand is unproven.'))
    assert 'Agent recommendation rejected' in synthesis.reviewer_responses[0].disposition
    assert not any(c.product=='8 ft Inflatable Black Cat' for c in synthesis.recommended_changes)

def test_explicit_reviewer_changes_honored(products):
    human = reviews('Modify','Replace fog with the solar ghosts, not another fog product.')
    human[0].requested_changes=[
        Change(product='LED Fog Machine',from_placement='In Store',to_placement='Removed',reason='Reviewer'),
        Change(product='Solar Pathway Ghosts (4-pc)',from_placement='Removed',to_placement='In Store',reason='Reviewer')]
    human[1] = Review(role=ROLES[1],decision='Disagree',comment='Defer my original pumpkin proposal to the financial reviewer.')
    syn = offline_synthesis(products,demo_analyses(products)[0],human)
    assert any(c.product=='Solar Pathway Ghosts (4-pc)' for c in syn.recommended_changes)
    assert validate_assortment(apply_changes(products,syn.recommended_changes)).valid

def test_conflicting_human_changes_not_silently_chosen(products):
    human = reviews('Modify','Put the fog item online.')
    human[0].requested_changes=[Change(product='LED Fog Machine',from_placement='In Store',to_placement='Online Only',reason='Test')]
    human[1]=Review(role=ROLES[1],decision='Modify',comment='Remove the fog item.',requested_changes=[Change(product='LED Fog Machine',from_placement='In Store',to_placement='Removed',reason='Test')])
    syn=offline_synthesis(products,demo_analyses(products)[0],human)
    assert not syn.recommended_changes
    assert any('conflicting' in x for x in syn.conflicts)

def test_infeasible_reviewer_changes_withheld(products):
    human=reviews('Modify','Add Dragon for excitement.')
    human[0].requested_changes=[Change(product='14 ft Giant Animated Dragon',from_placement='Removed',to_placement='In Store',reason='Test')]
    syn=offline_synthesis(products,demo_analyses(products)[0],human)
    assert not syn.recommended_changes
    assert any('withheld' in x for x in syn.conflicts)

def test_comments_required_and_unique_reviews(products):
    with pytest.raises(ValueError): Review(role=ROLES[0],decision='Modify')
    with pytest.raises(ValueError): Review(role=ROLES[0],decision='Disagree',comment=' ')
    with pytest.raises(ValueError): offline_synthesis(products,demo_analyses(products)[0],[reviews()[0]]*3)

def test_unknown_products_and_stale_changes_rejected(products):
    with pytest.raises(ValueError,match='Unknown product'):
        apply_changes(products,[Change(product='Invented',from_placement='Removed',to_placement='In Store',reason='Test')])
    with pytest.raises(ValueError,match='Stale'):
        apply_changes(products,[Change(product=products[0].item,from_placement='Removed',to_placement='Online Only',reason='Test')])

def test_evidence_must_match_exact_source(products):
    a=offline_perspective(products,'Financial')
    a.findings[0].evidence[0].value='999999999'
    with pytest.raises(ValueError,match='does not match'): validate_evidence(a,products)

def test_cached_analysis_invalidated_by_metrics_and_placements(products):
    edited=[p.model_copy(deep=True) for p in products]
    edited[0].gross_margin_dollars=123
    assert demo_analyses(edited)[1]=='Rule-based offline analysis'
    assert demo_analyses(placement(products,'LED Fog Machine','Removed'))[1]=='Rule-based offline analysis'

def test_stale_snapshot_cannot_finalize(products):
    analyses=demo_analyses(products)[0]
    syn=offline_synthesis(products,analyses,reviews())
    with pytest.raises(ValueError,match='stale'):
        finalize(products,products,analyses,reviews(),syn,MerchantDecision(decision='Override',rationale='Test'),'wrong','Demo','Demo')

def test_accept_must_match_synthesis(products):
    with pytest.raises(ValueError,match='Accept must match'): final_record(products,final_products=products)

def test_modify_must_change_placements(products):
    with pytest.raises(ValueError,match='Modify must change'): final_record(products,decision='Modify',rationale='Nothing changed')

def test_final_metrics_cannot_be_mutated(products):
    altered=[p.model_copy(deep=True) for p in products]
    altered[0].retail_price=1
    with pytest.raises(ValueError,match='placements only'): final_record(products,decision='Override',rationale='Test',final_products=altered)

def test_duplicate_placement_and_bad_facings_rejected(products):
    assert not validate_assortment(products+[products[0]]).placement_valid
    raw=[p.model_dump() for p in products]
    raw[0]['required_facings']=-3
    assert not validate_assortment(raw).data_valid
    raw[0]['required_facings']=1.5
    assert not validate_assortment(raw).data_valid
    raw[0]['placement']='Store and online'
    assert not validate_assortment(raw).placement_valid

def test_missing_historical_data_never_zero(products):
    for p in products:
        if p.source_type=='new_candidate':
            assert p.star_rating is None and p.reviews is None and p.full_price_sell_through is None
    with pytest.raises(ValueError):
        Product.model_validate({**products[-1].model_dump(),'star_rating':0})

def test_source_note_inconsistency_flagged(products):
    assert any('Required Facings are 2 and 1' in x for x in source_warnings(products))

def workbook_bytes(rows, title='Student Data'):
    w=Workbook();s=w.active;s.title=title
    for row in rows:s.append(row)
    out=BytesIO();w.save(out);return out.getvalue()

def test_renamed_headers_and_percentage_strings():
    rows=[['Item','Category','Current Channel','Required Facings','Gross Margin $','Full-Price Sell-Through'],
          ['A','Giants and Animatronics','In-Store',3,'$1,000','85%'],[],
          ['Item','Category','Required Facings','Mandatory Purchase Quantity','Potential GM $ based on Purchase Quantity'],
          ['B','Inflatables',1,20000,740000]]
    p=load_products(workbook_bytes(rows))
    assert p[0].full_price_sell_through==.85 and p[0].gross_margin_dollars==1000
    assert p[0].category=='Giants & Animatronics'
    assert p[1].mandatory_purchase_quantity==20000

def test_bad_uploads_fail_clearly():
    with pytest.raises(WorkbookError):load_products(b'not an excel file')
    with pytest.raises(WorkbookError,match='Student Data'):load_products(workbook_bytes([['x']],title='Wrong'))
    with pytest.raises(WorkbookError,match='No product rows'):load_products(workbook_bytes([['x']]))

def test_mock_live_calls_independent_and_structured(products):
    payloads=[]
    def parse(**kwargs):
        payloads.append(kwargs)
        system=kwargs['input'][0]['content']
        role=next(r for r in ROLES if '\nRole: '+r+'\n' in system)
        assert kwargs['text_format'].__name__ == 'WorkbookPerspective'
        assert not kwargs['store']
        content=json.loads(kwargs['input'][1]['content'])
        assert 'perspectives' not in content
        return SimpleNamespace(output_parsed=offline_perspective(products,role))
    client=SimpleNamespace(responses=SimpleNamespace(parse=parse))
    result=live_analyses(products,client=client,model='mock-model')
    assert len(payloads)==3 and set(result)==set(ROLES)

def test_mock_live_synthesis_receives_human_feedback(products):
    analyses=demo_analyses(products)[0]
    human=reviews('Disagree','Do not adopt supplier assumptions as historical evidence.')
    def parse(**kwargs):
        payload=json.loads(kwargs['input'][1]['content'])
        assert payload['human_reviews'][0]['comment']==human[0].comment
        assert len(payload['perspectives'])==3
        assert payload['validation']['total_facings']==16
        return SimpleNamespace(output_parsed=offline_synthesis(products,analyses,human))
    client=SimpleNamespace(responses=SimpleNamespace(parse=parse))
    assert live_synthesis(products,analyses,human,client=client).reviewer_responses[0].decision=='Disagree'

def test_live_synthesis_cannot_omit_reviews_or_break_rules(products):
    analyses=demo_analyses(products)[0]
    syn=offline_synthesis(products,analyses,reviews())
    syn.reviewer_responses.pop()
    with pytest.raises(ValueError,match='omitted'):validate_synthesis(syn,products,reviews())
    syn=offline_synthesis(products,analyses,reviews())
    syn.recommended_changes=[Change(product='14 ft Giant Animated Dragon',from_placement='Removed',to_placement='In Store',reason='Bad model output')]
    with pytest.raises(ValueError,match='validation'):validate_synthesis(syn,products,reviews())

def test_model_refusal_is_handled(products):
    client=SimpleNamespace(responses=SimpleNamespace(parse=Mock(return_value=SimpleNamespace(output_parsed=None))))
    with pytest.raises(ValueError,match='no structured'):live_analyses(products,client=client)

def test_csv_formula_injection_escaped(products):
    record=final_record(products)
    record['products'][0]['item']='=HYPERLINK("bad")'
    assert "'=HYPERLINK" in placements_csv(record)

def test_optional_missing_metrics_do_not_crash_offline_analysis(products):
    edited=[]
    optional=('retail_price','unit_cost','gross_margin_dollars','gross_margin_rate',
        'star_rating','reviews','full_price_sell_through','mandatory_purchase_quantity',
        'units_bought','units_sold_clearance','merchant_notes')
    for p in products:
        edited.append(Product.model_validate({**p.model_dump(),**{f:None for f in optional}}))
    analyses,source,_=demo_analyses(edited)
    assert len(analyses)==3 and source=='Rule-based offline analysis'
    assert any(e.value=='Not available' for a in analyses.values() for f in a.findings for e in f.evidence)

def test_exact_retail_cents_preserved_in_findings(products):
    a=offline_perspective(products,'Customer and Merchandising')
    assert '$29.98' in ' '.join(f.claim for f in a.findings)

def test_modify_final_assortment_success(products):
    analyses,source,_=demo_analyses(products)
    syn=offline_synthesis(products,analyses,reviews())
    proposed=apply_changes(products,syn.recommended_changes)
    changed=placement(placement(proposed,'24 in Light-Up Pumpkin Stack','Removed'),'Solar Pathway Ghosts (4-pc)','In Store')
    record=finalize(products,changed,analyses,reviews(),syn,
        MerchantDecision(decision='Modify',rationale='Use Solar Ghosts instead of Pumpkin Stack as the one-facing candidate.'),
        fingerprint(products),source,'Demo synthesis')
    assert record['validation']['valid']
    assert len(record['merchant_changes'])==2

def test_wrong_reviewer_comment_rejected(products):
    analyses=demo_analyses(products)[0]
    human=reviews('Modify','Keep original financial placements.')
    syn=offline_synthesis(products,analyses,human)
    syn.reviewer_responses[0].comment='Model ignored the actual comment'
    with pytest.raises(ValueError,match='preserve'):validate_synthesis(syn,products,human)

def test_repeated_change_rejected(products):
    change=Change(product='LED Fog Machine',from_placement='In Store',to_placement='Removed',reason='Test')
    with pytest.raises(ValueError,match='Duplicate'):apply_changes(products,[change,change])

def test_real_sdk_serialization_and_pydantic_parse_without_network(products):
    import httpx
    from openai import OpenAI
    captured=[]
    def handler(request):
        payload=json.loads(request.content)
        captured.append(payload)
        role=next(r for r in ROLES if '\nRole: '+r+'\n' in payload['input'][0]['content'])
        result=offline_perspective(products,role)
        payload_data=result.model_dump()
        for finding in payload_data['findings']:
            for reference in finding['evidence']: reference.pop('value')
        return httpx.Response(200,json={
            'id':'resp_test','object':'response','created_at':0,'status':'completed',
            'model':'mock-model','output':[{'id':'msg_test','type':'message','status':'completed',
            'role':'assistant','content':[{'type':'output_text','text':json.dumps(payload_data),'annotations':[]}]}]})
    client=OpenAI(api_key='test-key-not-real',http_client=httpx.Client(transport=httpx.MockTransport(handler)),max_retries=0,timeout=45)
    try:
        result=live_analyses(products,client=client,model='mock-model')
        assert len(result)==3
        assert all(p['text']['format']['type']=='json_schema' and p['text']['format']['strict'] for p in captured)
        assert all(p['store'] is False for p in captured)
    finally: client.close()

def test_audit_preserves_both_reviewed_and_final_snapshots(products):
    record=final_record(products)
    assert record['reviewed_products']==[p.model_dump() for p in products]
    assert record['products']!=record['reviewed_products']
    assert record['analysis_fingerprint']==fingerprint([Product.model_validate(p) for p in record['reviewed_products']])

def test_hot_reload_old_model_instances_remain_usable(products):
    from pydantic import create_model
    from agents import validate_reviews
    PreviousChange=create_model('PreviousChange',product=(str,...),from_placement=(str,...),to_placement=(str,...),reason=(str,...))
    old=PreviousChange(product='LED Fog Machine',from_placement='In Store',to_placement='Removed',reason='Old session object')
    assert next(p for p in apply_changes(products,[old]) if p.item==old.product).placement=='Removed'
    PreviousReview=create_model('PreviousReview',role=(str,...),decision=(str,...),comment=(str,...),requested_changes=(list,...))
    assert len(validate_reviews([PreviousReview(**r.model_dump()) for r in reviews()]))==3
    old_analyses={role:SimpleNamespace(model_dump=lambda a=a:a.model_dump()) for role,a in demo_analyses(products)[0].items()}
    synthesis=offline_synthesis(products,old_analyses,reviews('Modify','Retain the financial assortment.'))
    assert len(synthesis.recommended_changes)==2

def test_formatted_currency_evidence_normalizes_without_changing_facts(products):
    a=offline_perspective(products,'Financial')
    ref=a.findings[0].evidence[0]
    ref.value='$9,405,000'
    validate_evidence(a,products)
    assert ref.value=='9405000.0'

def test_formatted_percentage_evidence_matches_actual_value(products):
    from schemas import Evidence
    a=offline_perspective(products,'Financial')
    ref=Evidence(product='LED Fog Machine',field='full_price_sell_through',value='32%')
    a.findings[0].evidence.append(ref)
    validate_evidence(a,products)
    assert ref.value=='0.32'
    ref.value='33%'
    with pytest.raises(ValueError,match='does not match'):validate_evidence(a,products)

def test_safe_diagnostics_do_not_echo_sdk_messages():
    from errors import explain_error
    exc=ValueError('sk-secret-example must not appear')
    assert 'sk-secret' not in explain_error(exc)
    exc.code='insufficient_quota'
    assert 'Billing' in explain_error(exc)

def test_live_schema_restricts_references_to_actual_workbook(products):
    from live_schema import schema_for, hydrate_perspective
    data=offline_perspective(products,'Financial').model_dump()
    for f in data['findings']:
        for e in f['evidence']: e.pop('value')
    schema=schema_for(products)
    parsed=schema.model_validate(data)
    hydrated=hydrate_perspective(parsed,products)
    validate_evidence(hydrated,products)
    assert hydrated.findings[0].evidence[0].value=='9405000.0'
    data['findings'][0]['evidence'][0]['field']='invented_margin_metric'
    with pytest.raises(ValueError):schema.model_validate(data)
    data['findings'][0]['evidence'][0]['field']='gross_margin_dollars'
    data['findings'][0]['evidence'][0]['product']='Invented product'
    with pytest.raises(ValueError):schema.model_validate(data)
